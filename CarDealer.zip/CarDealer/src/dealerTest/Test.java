package dealerTest;

import dealerPD.Dealer;

public abstract class Test {
  
  public abstract void printTest(Dealer dealer);

}
